import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Location() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="text-center mb-16 md:mb-24">
          <p className="text-sm md:text-base font-semibold text-accent tracking-widest uppercase mb-4">
            Visit Us
          </p>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Studio Location
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Located in the heart of Ejipura, Bengaluru. We're easy to reach and ready to welcome you.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16">
          {/* Contact Information */}
          <div className="space-y-8 animate-fade-in-up">
            {/* Address */}
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Address</h3>
                <p className="text-muted-foreground text-lg">
                  Near Rama Temple, Ejipura
                  <br />
                  Bengaluru, Karnataka 560047
                  <br />
                  India
                </p>
              </div>
            </div>

            {/* Phone */}
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Phone</h3>
                <a href="tel:+919876543210" className="text-accent hover:text-accent/80 text-lg font-semibold">
                  +91 98765 43210
                </a>
                <p className="text-muted-foreground">Available 9 AM - 6 PM, Mon-Sat</p>
              </div>
            </div>

            {/* Email */}
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Email</h3>
                <a href="mailto:hello@v2focusstudio.com" className="text-accent hover:text-accent/80 text-lg font-semibold">
                  hello@v2focusstudio.com
                </a>
                <p className="text-muted-foreground">We respond within 24 hours</p>
              </div>
            </div>

            {/* Hours */}
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Clock className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Studio Hours</h3>
                <p className="text-muted-foreground">
                  Monday - Saturday: 9:00 AM - 6:00 PM
                  <br />
                  Sunday: By appointment only
                </p>
              </div>
            </div>
          </div>

          {/* Google Maps Embed */}
          <div className="animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <div className="w-full h-96 md:h-full min-h-96 rounded-lg overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.8198748456717!2d77.59896!3d13.00583!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae17e8b8b8b8b9%3A0x8b8b8b8b8b8b8b8b!2sEjipura%2C%20Bengaluru!5e0!3m2!1sen!2sin!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>

        {/* Directions CTA */}
        <div className="mt-12 text-center">
          <a
            href="https://maps.google.com/?q=Ejipura+Bengaluru"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold rounded-lg transition-all hover:shadow-lg"
          >
            Get Directions
          </a>
        </div>
      </div>
    </section>
  );
}
