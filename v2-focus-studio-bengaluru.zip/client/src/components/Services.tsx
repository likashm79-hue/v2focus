import { Heart, Video, Baby, Users } from "lucide-react";

const services = [
  {
    id: 1,
    title: "Wedding Photography",
    description: "Cinematic storytelling that captures the essence of your special day with artistic precision and emotional depth.",
    icon: Users,
  },
  {
    id: 2,
    title: "Maternity Shoots",
    description: "Celebrate the beauty of motherhood with elegant, timeless portraits that honor this precious journey.",
    icon: Heart,
  },
  {
    id: 3,
    title: "Newborn & Baby Shoots",
    description: "Tender, intimate moments with your little ones captured in a safe, comfortable studio environment.",
    icon: Baby,
  },
  {
    id: 4,
    title: "Cinematic Videography",
    description: "Breathtaking video production that transforms your memories into cinematic masterpieces.",
    icon: Video,
  },
];

export default function Services() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="text-center mb-16 md:mb-24">
          <p className="text-sm md:text-base font-semibold text-accent tracking-widest uppercase mb-4">
            Our Expertise
          </p>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Premium Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Each service is crafted with meticulous attention to detail and artistic vision.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="group p-8 md:p-10 border border-border rounded-lg transition-all hover:shadow-lg hover:-translate-y-2 animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Icon */}
                <div className="w-16 h-16 bg-accent/10 rounded-lg flex items-center justify-center mb-6 group-hover:bg-accent/20 transition-all">
                  <Icon className="w-8 h-8 text-accent" />
                </div>

                {/* Content */}
                <h3 className="text-2xl md:text-3xl font-bold mb-4">{service.title}</h3>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  {service.description}
                </p>

                {/* Divider */}
                <div className="h-1 w-12 bg-accent mt-6 group-hover:w-full transition-all duration-500" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
