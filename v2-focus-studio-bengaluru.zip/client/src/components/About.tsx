export default function About() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16 items-center">
          {/* Left: Image */}
          <div className="relative h-96 md:h-full min-h-96 rounded-lg overflow-hidden animate-fade-in-up">
            <img
              src="https://images.unsplash.com/photo-1606933248051-5ce98adc3b2f?w=600&h=600&fit=crop"
              alt="V2 Focus Studio Team"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 to-transparent" />
          </div>

          {/* Right: Content */}
          <div className="space-y-8 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <div>
              <p className="text-sm md:text-base font-semibold text-accent tracking-widest uppercase mb-4">
                Our Story
              </p>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                Since 2014
              </h2>
            </div>

            <p className="text-lg text-muted-foreground leading-relaxed">
              V2 Focus Studio was founded with a singular vision: to create timeless, cinematic memories that tell the authentic stories of life's most precious moments. For over a decade, we've been honored to capture weddings, celebrate motherhood, welcome newborns, and craft cinematic narratives for families across Bengaluru.
            </p>

            <p className="text-lg text-muted-foreground leading-relaxed">
              Our philosophy is rooted in the belief that photography and videography are not just about documentation—they're about emotion, artistry, and connection. Every frame is meticulously crafted to preserve the beauty, joy, and intimacy of your most cherished experiences.
            </p>

            {/* Values */}
            <div className="grid grid-cols-2 gap-6 pt-4">
              <div>
                <h4 className="font-bold text-lg mb-2">Artistry</h4>
                <p className="text-muted-foreground text-sm">
                  Every shot is a masterpiece, carefully composed and edited.
                </p>
              </div>
              <div>
                <h4 className="font-bold text-lg mb-2">Authenticity</h4>
                <p className="text-muted-foreground text-sm">
                  We capture genuine emotions and real moments, not poses.
                </p>
              </div>
              <div>
                <h4 className="font-bold text-lg mb-2">Professionalism</h4>
                <p className="text-muted-foreground text-sm">
                  Timely delivery and exceptional service are our standards.
                </p>
              </div>
              <div>
                <h4 className="font-bold text-lg mb-2">Innovation</h4>
                <p className="text-muted-foreground text-sm">
                  We blend classic techniques with modern cinematography.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
