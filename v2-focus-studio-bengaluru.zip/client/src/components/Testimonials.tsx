import { useState } from "react";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

const testimonials = [
  {
    id: 1,
    name: "Priya & Arjun",
    role: "Wedding Couple",
    rating: 5,
    quote: "V2 Focus Studio captured our wedding day with such artistry and grace. Every frame tells our love story beautifully. We couldn't have asked for better.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
  },
  {
    id: 2,
    name: "Anjali Sharma",
    role: "Maternity Client",
    rating: 5,
    quote: "The maternity shoot was an incredible experience. The team made me feel so comfortable and beautiful. The photos are absolutely stunning and timeless.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
  },
  {
    id: 3,
    name: "Vikram & Deepa",
    role: "Newborn Parents",
    rating: 5,
    quote: "Our newborn photos are precious beyond words. V2 Focus Studio's professionalism and creativity resulted in images we'll treasure forever.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
  },
  {
    id: 4,
    name: "Rohan Kapoor",
    role: "Videography Client",
    rating: 5,
    quote: "The cinematic video production was phenomenal. They transformed our special moments into a film that's better than we could have imagined.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
  },
];

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const current = testimonials[currentIndex];

  return (
    <section className="py-20 md:py-32 bg-muted/30">
      <div className="container">
        {/* Section Header */}
        <div className="text-center mb-16 md:mb-24">
          <p className="text-sm md:text-base font-semibold text-accent tracking-widest uppercase mb-4">
            Client Love
          </p>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Testimonials
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Hear from families and couples who've trusted us with their most precious moments.
          </p>
        </div>

        {/* Testimonial Carousel */}
        <div className="max-w-3xl mx-auto">
          <div className="bg-background rounded-lg p-8 md:p-12 shadow-lg animate-fade-in-up">
            {/* Stars */}
            <div className="flex gap-1 mb-6">
              {Array.from({ length: current.rating }).map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-accent text-accent" />
              ))}
            </div>

            {/* Quote */}
            <blockquote className="text-xl md:text-2xl font-light text-foreground mb-8 leading-relaxed">
              "{current.quote}"
            </blockquote>

            {/* Author */}
            <div className="flex items-center gap-4 mb-8">
              <img
                src={current.image}
                alt={current.name}
                className="w-12 h-12 rounded-full object-cover"
              />
              <div>
                <p className="font-semibold text-foreground">{current.name}</p>
                <p className="text-sm text-muted-foreground">{current.role}</p>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex gap-4 pt-8 border-t border-border">
              <Button
                onClick={prev}
                variant="outline"
                size="icon"
                className="rounded-full"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <Button
                onClick={next}
                variant="outline"
                size="icon"
                className="rounded-full"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
              <div className="flex-1 flex items-center justify-end gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentIndex ? "bg-accent w-8" : "bg-border"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
