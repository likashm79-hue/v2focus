import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const pricingPlans = [
  {
    id: 1,
    category: "Photography",
    name: "Essentials",
    price: "₹25,000",
    description: "Perfect for intimate moments",
    features: [
      "4 hours coverage",
      "500+ edited photos",
      "Online gallery",
      "2 printed albums",
      "Same-day previews",
    ],
    highlighted: false,
  },
  {
    id: 2,
    category: "Photography",
    name: "Premium",
    price: "₹50,000",
    description: "Our most popular choice",
    features: [
      "8 hours coverage",
      "1000+ edited photos",
      "Online gallery + prints",
      "4 premium albums",
      "Drone photography",
      "Cinematic highlights reel",
      "Unlimited revisions",
    ],
    highlighted: true,
  },
  {
    id: 3,
    category: "Videography",
    name: "Cinematic",
    price: "₹60,000",
    description: "Full-day coverage",
    features: [
      "12 hours coverage",
      "4K video quality",
      "Professional color grading",
      "Cinematic highlights (5 min)",
      "Full ceremony film (30 min)",
      "Drone footage",
      "Music licensing included",
    ],
    highlighted: false,
  },
  {
    id: 4,
    category: "Videography",
    name: "Masterpiece",
    price: "₹1,00,000",
    description: "Complete coverage",
    features: [
      "Full event coverage",
      "4K + 8K video",
      "Multiple camera angles",
      "Cinematic highlights (8 min)",
      "Full event film (60 min)",
      "Drone + gimbal shots",
      "Professional editing suite",
      "Blu-ray delivery",
    ],
    highlighted: true,
  },
];

export default function Pricing() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className="text-center mb-16 md:mb-24">
          <p className="text-sm md:text-base font-semibold text-accent tracking-widest uppercase mb-4">
            Investment
          </p>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Pricing Packages
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Transparent pricing for exceptional quality. Custom packages available upon request.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <div
              key={plan.id}
              className={`relative rounded-lg overflow-hidden animate-fade-in-up ${
                plan.highlighted
                  ? "md:col-span-1 border-2 border-accent shadow-2xl scale-105 md:scale-100"
                  : "border border-border"
              } bg-background p-8 md:p-10 transition-all hover:shadow-lg`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {plan.highlighted && (
                <div className="absolute top-4 right-4 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold">
                  Popular
                </div>
              )}

              {/* Category */}
              <p className="text-xs font-semibold text-accent tracking-widest uppercase mb-2">
                {plan.category}
              </p>

              {/* Plan Name */}
              <h3 className="text-3xl font-bold mb-2">{plan.name}</h3>
              <p className="text-muted-foreground mb-6">{plan.description}</p>

              {/* Price */}
              <div className="mb-8">
                <span className="text-5xl font-bold">{plan.price}</span>
                <p className="text-muted-foreground text-sm mt-2">One-time investment</p>
              </div>

              {/* Features */}
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <Button
                onClick={scrollToContact}
                className={`w-full font-semibold py-3 ${
                  plan.highlighted
                    ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                    : "bg-foreground hover:bg-foreground/90 text-background"
                }`}
              >
                Book This Package
              </Button>
            </div>
          ))}
        </div>

        {/* Custom Package CTA */}
        <div className="mt-16 text-center">
          <p className="text-lg text-muted-foreground mb-4">
            Looking for a custom package?
          </p>
          <Button
            onClick={scrollToContact}
            variant="outline"
            className="border-accent text-accent hover:bg-accent/10"
          >
            Get a Custom Quote
          </Button>
        </div>
      </div>
    </section>
  );
}
