import { Instagram, Facebook, Linkedin } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background py-12 md:py-16">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold">V2</span>
              </div>
              <span className="font-bold text-lg">V2 Focus Studio</span>
            </div>
            <p className="text-background/70 text-sm">
              Premium photography and videography since 2014.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-background/70">
              <li>
                <a href="#services" className="hover:text-background transition-colors">
                  Wedding Photography
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-background transition-colors">
                  Maternity Shoots
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-background transition-colors">
                  Newborn & Baby
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-background transition-colors">
                  Videography
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-bold mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-background/70">
              <li>
                <a href="#about" className="hover:text-background transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-background transition-colors">
                  Portfolio
                </a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-background transition-colors">
                  Pricing
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-background transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h4 className="font-bold mb-4">Follow Us</h4>
            <div className="flex gap-4">
              <a
                href="https://instagram.com/v2focusstudio"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-background/20 hover:bg-accent rounded-full flex items-center justify-center transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="https://facebook.com/v2focusstudio"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-background/20 hover:bg-accent rounded-full flex items-center justify-center transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com/company/v2focusstudio"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-background/20 hover:bg-accent rounded-full flex items-center justify-center transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-background/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-background/70">
            <p>
              &copy; {currentYear} V2 Focus Studio. All rights reserved. Bengaluru, India.
            </p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-background transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-background transition-colors">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
