import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-foreground flex items-center justify-center pt-20">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-foreground/80 via-foreground/60 to-foreground/40" />
      
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10 container text-center text-background px-4 py-20">
        <div className="space-y-6 md:space-y-8">
          {/* Animated tagline */}
          <div className="space-y-2 animate-fade-in-up">
            <p className="text-sm md:text-base font-semibold text-accent tracking-widest uppercase">
              Premium Photography & Videography
            </p>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight">
              Capture Your
              <br />
              <span className="text-accent">Precious Moments</span>
            </h1>
          </div>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-background/80 max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            Since 2014, V2 Focus Studio has been crafting cinematic memories for families, couples, and newborns in Bengaluru with unmatched artistry and precision.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            <Button
              onClick={() => scrollToSection("contact")}
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-8 py-3 text-base transition-all hover:scale-105"
            >
              Book Your Session
            </Button>
            <Button
              onClick={() => scrollToSection("portfolio")}
              variant="outline"
              className="border-background/50 text-background hover:bg-background/10 font-semibold px-8 py-3 text-base transition-all hover:scale-105"
            >
              View Portfolio
            </Button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <button
            onClick={() => scrollToSection("services")}
            className="flex flex-col items-center gap-2 text-background/60 hover:text-background transition-all"
          >
            <span className="text-xs font-semibold uppercase tracking-wider">Scroll</span>
            <ChevronDown className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
