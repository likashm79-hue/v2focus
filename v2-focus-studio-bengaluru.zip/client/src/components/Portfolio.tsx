import { useState } from "react";
import { X } from "lucide-react";

const portfolioItems = [
  {
    id: 1,
    category: "wedding",
    title: "Elegant Wedding Ceremony",
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=600&fit=crop",
  },
  {
    id: 2,
    category: "maternity",
    title: "Beautiful Maternity Portrait",
    image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=600&h=600&fit=crop",
  },
  {
    id: 3,
    category: "newborn",
    title: "Newborn Baby Photography",
    image: "https://images.unsplash.com/photo-1503454537688-e6694d30e0ad?w=600&h=600&fit=crop",
  },
  {
    id: 4,
    category: "videography",
    title: "Cinematic Wedding Film",
    image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&h=600&fit=crop",
  },
  {
    id: 5,
    category: "wedding",
    title: "Romantic Couple Portrait",
    image: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=600&h=600&fit=crop",
  },
  {
    id: 6,
    category: "maternity",
    title: "Expecting Mother Glow",
    image: "https://images.unsplash.com/photo-1516627145497-ae3dcd1591d7?w=600&h=600&fit=crop",
  },
  {
    id: 7,
    category: "newborn",
    title: "Peaceful Newborn Sleep",
    image: "https://images.unsplash.com/photo-1527489377706-5bf97e608852?w=600&h=600&fit=crop",
  },
  {
    id: 8,
    category: "videography",
    title: "Cinematic Moments",
    image: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=600&h=600&fit=crop",
  },
];

export default function Portfolio() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedImage, setSelectedImage] = useState<(typeof portfolioItems)[0] | null>(null);

  const categories = ["all", "wedding", "maternity", "newborn", "videography"];

  const filteredItems =
    activeCategory === "all"
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === activeCategory);

  return (
    <section className="py-20 md:py-32 bg-muted/30">
      <div className="container">
        {/* Section Header */}
        <div className="text-center mb-16 md:mb-24">
          <p className="text-sm md:text-base font-semibold text-accent tracking-widest uppercase mb-4">
            Our Work
          </p>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Portfolio Gallery
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore our curated collection of timeless moments captured with artistry and passion.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-3 justify-center mb-12 md:mb-16">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full font-semibold text-sm transition-all ${
                activeCategory === category
                  ? "bg-accent text-accent-foreground"
                  : "bg-background border border-border text-foreground hover:border-accent"
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              onClick={() => setSelectedImage(item)}
              className="group relative aspect-square overflow-hidden rounded-lg cursor-pointer animate-fade-in-up transition-all hover:scale-105"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <img
                src={item.image}
                loading="lazy"
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/40 transition-all duration-300 flex items-end justify-start p-4">
                <div className="text-background opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="font-semibold text-sm">{item.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-foreground/90 flex items-center justify-center p-4 animate-fade-in-up"
          onClick={() => setSelectedImage(null)}
        >
          <div
            className="relative max-w-4xl w-full aspect-square md:aspect-auto md:max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={selectedImage.image}
              alt={selectedImage.category}
              loading="lazy"
              className="w-full h-full object-cover rounded-lg"
            />
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 bg-background/80 hover:bg-background text-foreground p-2 rounded-full transition-all"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="absolute bottom-4 left-4 right-4 bg-foreground/80 text-background p-4 rounded-lg">
              <p className="font-semibold">{selectedImage.title}</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
